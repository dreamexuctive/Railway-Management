<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact Us</title>
</head>
<?php 
    session_start();
    if(isset($_SESSION['username']))
        include "template/header-name.php";
    else
        include "template/header.php";
?>

<div style="margin-top:150px;">
    <form style="padding:50px;">
        <h3>ASIM jillani</h3><br>
        <a href="https://www.linkedin.com/in/example/" class="register"><i class="fab fa-linkedin pr-1"></i>Linkedin</a>
        <a href="example@students.au.edu.pk" class="register"><i class="fab fa-google pr-1"></i> Gmail</a>
        <a href="https://github.com/dreamexuctive/Railway-Management."class="register"><i class="fab fa-github pr-1"></i> Github</a>
        <br><br><br>
        <h3>Hassan Sajjad</h3><br>
        <a href="linkedin.com/in/example" class="register"><i class="fab fa-linkedin pr-1"></i>Linkedin</a>
        <a href="example@students.au.edu.pk" class="register"><i class="fab fa-google pr-1"></i> Gmail</a>
        <a href="https://github.com/dreamexuctive/Railway-Management."class="register"><i class="fab fa-github pr-1"></i> Github</a>
        <br><br><br>
        
        <a href="index.php" class="register">Back</a>
    </form>
    
</div>

<?php include "template/footer.php" ?>

</html>