<?php
session_start();
include "config/connection.php";

$errors = array('username' => '', 'password' => '', 'authenticate' => '');
$message = '';

if (isset($_SESSION['username'])) {
    header('Location: user.php');
    exit();
}

if (isset($_POST['signin'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (empty($username)) {
        $errors['username'] = 'Username is required';
    }
    if (empty($password)) {
        $errors['password'] = 'Password is required';
    }

    if (!array_filter($errors)) {
        $username = $conn->real_escape_string($username);
        $password = $conn->real_escape_string($password);

        // Query to check the user username and plain text password
        $userQuery = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
        $userResult = $conn->query($userQuery);

        if ($userResult === FALSE) {
            $message = "Invalid Username or Password!";
        } else {
            if ($userResult->num_rows > 0) {
                $_SESSION['username'] = $username;
                header('Location: user.php');
                exit();
            } else {
                $message = "Invalid Username or Password!";
            }
        }

        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<?php include "template/header.php" ?>
<div style="margin-top:100px;">
<form action="index.php" method="POST">
    <h3 class="heading">Welcome to Railway</h3>
  <label>
    <p class="label-txt">ENTER YOUR USERNAME</p>
    <input type="text" class="input" name="username" value="<?php echo htmlspecialchars($username) ?>">
    <div class="line-box">
      <div class="line"></div>
    </div>
    <p class= "bg-danger text-white"><?php echo htmlspecialchars($errors['username'])?></p>
  </label>
  <label>
    <p class="label-txt">ENTER YOUR PASSWORD</p>
    <input type="password" class="input" name="password" value="<?php echo htmlspecialchars($password) ?>">
    <div class="line-box">
      <div class="line"></div>
    </div>
    <p class= "bg-danger text-white"><?php echo htmlspecialchars($errors['password'])?></p>
  </label>
  <p class= "bg-danger text-white"><?php echo htmlspecialchars($errors['authenticate'])?></p>
  <button type="submit" name="signin" value="submit">Sign-In</button>
  <a href="register.php" class="register">Not A Member? Register</a>
</form>
</div>
<?php include "template/footer.php" ?>

</html>