<footer>
  <div class="footer bg-light">

    <p>© Copyright 2024 </p>
    
  </div>
</footer>
</body>
